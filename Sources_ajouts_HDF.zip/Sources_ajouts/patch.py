import json, sys
src, out = sys.argv[1], sys.argv[2]
s = open(src, encoding='utf-8').read()
def rep(old, new, n=1):
    global s
    c = s.count(old)
    assert c == n, (old[:80], c)
    s = s.replace(old, new)

# 1. données
ort = open('ort_hdf.txt').read().strip()
mh = open('mh_hdf.txt').read().strip()
lp = open('loyers_prives_hdf_compact.txt').read().strip()
ls = open('loyers_sociaux_rpls2024_HDF.csv').read().strip()
blob = json.dumps({'ortj': json.load(open('ort_hdf.json')), 'mh': mh, 'lp': lp, 'ls': ls}, ensure_ascii=False).replace('</', '<\\/')
rep('<script type="application/json" id="zeData">', '<script type="application/json" id="plusData">' + blob + '</script>\n<script type="application/json" id="zeData">')

# 2. module
rep('/* ----- sources visibles et infobulles', open('app_plus.js', encoding='utf-8').read() + '\n/* ----- sources visibles et infobulles')

# 3. blocs dans la synthèse
rep("setTimeout(()=>zaRun(pt,R),50)",
    "setTimeout(()=>zaRun(pt,R),50);h+='<div id=\"plusbox\" class=\"sit\" style=\"border:1px solid #E7D3DA;background:#FCF7F9\"><div class=\"lab\">ORT et patrimoine protégé</div><div style=\"font-size:13px;color:var(--mut)\">Recherche en cours…</div></div><div id=\"loybox\" class=\"sit\" style=\"border:1px solid #D6E2EF;background:#F5F9FD\"><div class=\"lab\">Loyers dans la commune</div><div style=\"font-size:13px;color:var(--mut)\">Recherche en cours…</div></div>';setTimeout(()=>plusRun(pt,R),60)")

# 4. zoom précis
rep("am.fitBounds(L.latLng(pt.lat,pt.lon).toBounds(R*2200),{padding:[20,20]})",
    "(window.__rayonB=L.latLng(pt.lat,pt.lon).toBounds(R*2200),am.setView([pt.lat,pt.lon],17),zoomCtl())")
rep("zeLayer();zaInit();", """zeLayer();zaInit();plusInit();""")
s = s.replace("/* ----- ORT, monuments historiques, loyers", """let __zc=null;function zoomCtl(){if(__zc)return;const C=L.Control.extend({options:{position:'topleft'},onAdd(){const d=L.DomUtil.create('div');d.style.cssText='display:flex;gap:6px';
 const b1=L.DomUtil.create('button','fsb',d);b1.type='button';b1.textContent='Adresse';b1.title='Zoomer au niveau de la rue sur l\\'adresse analysée';
 const b2=L.DomUtil.create('button','fsb',d);b2.type='button';b2.textContent='Tout le rayon';b2.title='Afficher l\\'ensemble du rayon d\\'analyse';
 L.DomEvent.disableClickPropagation(d);b1.onclick=()=>{if(A.pt)am.setView([A.pt.lat,A.pt.lon],17)};b2.onclick=()=>{if(window.__rayonB)am.fitBounds(window.__rayonB,{padding:[20,20]})};return d}});__zc=new C().addTo(am)}
/* ----- ORT, monuments historiques, loyers""", 1)

# 5. cases à cocher
rep("""Zones d'emploi (Insee)</label>""", """Zones d'emploi (Insee)</label>
    <label class="tog" data-tip="Monuments historiques classés (bordeaux) et inscrits (rose), base Mérimée du ministère de la Culture. Visibles à partir du zoom ville ; en zoomant sur l'adresse, les cercles pointillés de 500 m (abords) des monuments les plus proches apparaissent. Clic : fiche officielle du monument."><input type="checkbox" id="ly-mh" checked><span class="lg" style="background:#8E2C48;border-radius:50%"></span> Monuments historiques et abords</label>
    <label class="tog" data-tip="Communes couvertes par une opération de revitalisation de territoire (ORT), dont Action cœur de ville (ACV) et Petites villes de demain (PVD). Source : ministère de la Cohésion des territoires."><input type="checkbox" id="ly-ort" checked><span class="lg" style="background:#0B6E4F;border-radius:3px"></span> Communes en ORT</label>""")

# 6. sources des blocs
rep('[/^Temps de trajet/i,"IGN Géoplateforme, itinéraire routier (BD TOPO), calculé en direct"]',
    '[/^Temps de trajet/i,"IGN Géoplateforme, itinéraire routier (BD TOPO), calculé en direct"],\n [/^ORT et patrimoine/i,"ministère de la Cohésion des territoires (ORT) ; ministère de la Culture, base Mérimée"],\n [/^Loyers/i,"RPLS au 1er janvier 2024 (parc social) ; Carte des loyers 2025 (parc privé)"]')

# 7. export CSV
rep(".concat(A.za&&A.za.length?",
    ".concat(A.plus?[[],['Commune (code Insee)','ORT : commune','ORT : programme','ORT : statut','ORT : date de signature','ORT : fin estimée','ORT : intercommunalité','Loyer social médian (€/m²)','Logements sociaux mesurés','Loyer privé appartement (€/m²)','Loyer privé maison (€/m²)'],[A.plus.commune].concat(A.plus.ort||['non','','','','','']).concat(A.plus.loy||[])]:[]).concat(A.plus&&A.plus.mh&&A.plus.mh.length?[[],['Monument historique','Protection','Année de protection','Référence Mérimée','Distance (m)']].concat(A.plus.mh):[]).concat(A.za&&A.za.length?")

# 8. matrice des droits de réservation : définitions explicites
rep("""<th class="n">Logts rayon</th><th class="n">Réservés</th><th class="n">Droits dépt</th>""",
    """<th class="n" data-tip="Logements sociaux de ce bailleur situés dans le rayon autour de l'adresse (RPLS 2024, adresses géolocalisées). Périmètre : le rayon.">Logts rayon</th><th class="n" data-tip="Logements réservés par Action Logement chez ce bailleur lors des engagements financiers 2018-2025 (POLARIS). Périmètre : les communes entières qui touchent le rayon, pas seulement le rayon.">Réservés 2018-2025</th><th class="n" data-tip="Droits de réservation d'Action Logement encore actifs chez ce bailleur au 31/12/2025 (ANCOLS) : droits uniques de l'ancien et du neuf, et droits de suite déjà livrés. Périmètre : tout le département.">Stock de droits dépt</th>""")
rep("""<summary>Droits de réservation Action Logement""", """<summary data-tip="Pour chaque bailleur présent autour de l'adresse : son parc dans le rayon, ce qu'Action Logement y a réservé, le stock de droits qu'il doit encore à Action Logement et le temps pour l'écouler. Chaque colonne a son propre périmètre, voir le tableau d'explication sous la liste.">Droits de réservation Action Logement""")
old_note_start = '<div class="note">Réservés : POLARIS, engagements 2018-2025 dans les communes du rayon.'
i = s.index(old_note_start); j = s.index('</div>', i) + 6
s = s[:i] + """<div style="margin-top:8px;border:1px solid var(--line);border-radius:8px;padding:8px 10px;font-size:12px;line-height:1.45;background:#FAFBFC"><div style="font-weight:700;color:var(--ink2);margin-bottom:5px">Comment lire ce tableau : chaque colonne a son propre périmètre</div>
<div style="margin-bottom:5px"><b>Logts rayon</b> : logements sociaux du bailleur <u>dans le rayon</u> autour de l'adresse. <span style="color:var(--mut)">RPLS au 01/01/2024.</span></div>
<div style="margin-bottom:5px"><b>Réservés 2018-2025</b> : logements qu'Action Logement a réservés chez ce bailleur en échange d'un financement, <u>sur les communes entières</u> qui touchent le rayon. <span style="color:var(--mut)">POLARIS, engagements 2018-2025.</span></div>
<div style="margin-bottom:5px"><b>Stock de droits dépt</b> : droits encore actifs, c'est-à-dire les logements qu'Action Logement peut encore proposer à ses salariés chez ce bailleur, <u>dans tout le département ${DEP}</u>. <span style="color:var(--mut)">ANCOLS au 31/12/2025.</span></div>
<div style="margin-bottom:5px"><b>Durée d'écoulement</b> (pastille sous le nom) : années pour consommer ce stock au rythme des familles logées 2023-2025 = stock ÷ familles logées par an, <u>tous territoires du bailleur, France entière</u>. Au-delà de 30 ans : « Plus de 30 ans ».</div>
<div style="color:var(--mut)">Les trois nombres ne s'additionnent pas et ne se comparent pas directement : périmètres et dates différents. « Réservés » peut dépasser « Logts rayon » car il porte sur toute la commune.</div></div>""" + s[j:]

# 9. Portrait : préciser QPV ou commune partout
rep("""<div style="color:${C.mut};margin-top:3px">${q.com} · ${code}</div>""",
    """<div style="color:${C.mut};margin-top:3px"><span style="background:#E0F3F1;color:#0E6E68;border-radius:4px;padding:1px 6px;font-weight:700;font-size:11.5px" data-tip="Quartier prioritaire de la politique de la ville (géographie 2024).">QPV</span> code ${code} · ${/,/.test(q.com)?'communes':'commune'} : ${q.com.replace(/,\s*/g,', ')}</div>""")
rep("""À <b>${x.n||x.c}</b>, les QPV regroupent""", """<span data-tip="Tous les quartiers prioritaires de cette commune réunis, pas seulement le quartier affiché.">Commune <b>${x.n||x.c}</b> : l'ensemble de ses QPV regroupe</span>""")
rep("""'habitants'],[dens""", """'habitants du quartier'],[dens""")
rep("""document.getElementById('qvq').value=q.n+' — '+q.com+' ('+code+')';""", """document.getElementById('qvq').value='QPV '+q.n+' · '+(/,/.test(q.com)?'communes : ':'commune : ')+q.com.replace(/,\s*/g,', ')+' ('+code+')';""")

rep("<li>Données Action Logement : usage interne uniquement.</li></ul></section>", "<li>ORT : liste des communes du ministère de la Cohésion des territoires (13/10/2026) ; la commune de l'adresse vient du géocodage inverse de l'IGN.</li><li>Monuments historiques : base Mérimée (27/08/2025). Les abords sont représentés par le cercle de 500 m, règle par défaut ; un périmètre délimité des abords peut le remplacer, à vérifier dans le PLU.</li><li>Loyers : social, médiane du loyer principal au m² du RPLS au 01/01/2024, hors charges ; privé, Carte des loyers 2025, loyers d'annonce charges comprises. L'écart affiché est un ordre de grandeur, légèrement surestimé à cause des charges.</li><li>Droits de réservation : « Logts rayon » porte sur le rayon, « Réservés » sur les communes entières du rayon, « Stock de droits » sur le département et la durée d'écoulement sur tout le bailleur en France. Ces nombres ne se comparent pas directement.</li><li>Données Action Logement : usage interne uniquement.</li></ul></section>")
s = s.replace('</style>', '.leaflet-top,.leaflet-bottom{z-index:400}</style>', 1)
open(out, 'w', encoding='utf-8').write(s)
print('ok', len(s))
