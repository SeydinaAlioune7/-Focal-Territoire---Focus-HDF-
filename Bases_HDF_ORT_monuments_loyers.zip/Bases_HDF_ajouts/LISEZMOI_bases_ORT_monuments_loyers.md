# Bases ajoutées à l'outil (copie DR Hauts-de-France), octobre 2026

Ces fichiers sont les données brutes utilisées pour les blocs « ORT et patrimoine protégé » et « Loyers dans la commune » de l'onglet Analyse d'une adresse. Ils sont enregistrés ici pour pouvoir refaire ou vérifier les chiffres.

| Fichier | Contenu | Producteur | Date des données | Page officielle |
| --- | --- | --- | --- | --- |
| `ORT_communes_liste_nationale_2026-10-13.csv` | Toutes les communes couvertes par une opération de revitalisation de territoire (France entière, 2 798 lignes) : programme (ACV, PVD, VA), signature, date | Ministère de la Cohésion des territoires (DGALN) | Extraction du 13/10/2026 | https://www.data.gouv.fr/datasets/63c69d70de98bf9a1fa11948 |
| `Monuments_historiques_HDF_Merimee.csv` | 3 178 immeubles protégés au titre des monuments historiques de l'Aisne, du Nord, de l'Oise, du Pas-de-Calais et de la Somme, avec coordonnées | Ministère de la Culture, base Mérimée | Mise à jour du 27/08/2025 | https://www.data.gouv.fr/datasets/5af120e5b595087cfabcde81 |
| `carte_loyers_2025_HDF_loyers_*.csv` (4 fichiers) | Loyer d'annonce estimé par commune (€/m², charges comprises) : appartement, appartement 1-2 pièces, 3 pièces et plus, maison. Région Hauts-de-France, 3 782 communes | Ministère de la Transition écologique (DHUP), ANIL, données SeLoger et leboncoin | Annonces 2025, publié le 11/12/2025 | https://www.data.gouv.fr/datasets/693aa2feed1bf4da603faa49 |
| `Loyers_sociaux_RPLS2024_HDF_par_commune.csv` | Loyer social médian par commune (€/m² de surface habitable, hors charges), quartiles, loyer médian en QPV | RPLS au 1er janvier 2024, via le modèle Power BI « FICHE BAILLEUR » | 01/01/2024 | requête dans `Loyers_sociaux_requete_DAX.dax` |

## Comment les chiffres sont calculés

- **ORT :** la commune de l'adresse est identifiée par le service de géocodage inverse de l'IGN, à partir du point exact. Si l'IGN ne répond pas, l'outil prend la commune la plus proche. Une commune est « en ORT » si sa convention est signée, terminée ou en cours. Les conventions non signées sont signalées, mais pas comptées.
- **Monuments historiques :** distance à vol d'oiseau entre l'adresse et chaque monument.
- **Abords :** la règle par défaut du code du patrimoine est un cercle de 500 m autour du monument. Le périmètre réel a pu être redéfini en périmètre délimité des abords (PDA). Pour un projet, il faut le vérifier dans le plan local d'urbanisme ou sur le Géoportail de l'urbanisme.
- **Loyer social :** loyer principal mensuel ÷ surface habitable, pour chaque logement loué. On retient la médiane de la commune : la moitié des logements est en dessous. Les quartiles bornent la moitié centrale des logements. Les valeurs aberrantes sont exclues (loyer nul, surface inférieure à 9 m², plus de 40 €/m²).
- **Loyer privé :** valeur estimée par le ministère.
  - TYPPRED = « commune » : l'estimation est propre à la commune.
  - TYPPRED = « maille » : il y a trop peu d'annonces, la valeur est estimée sur un groupe de communes voisines.
  - `lwr.IPm2` et `upr.IPm2` encadrent la valeur à 95 %.
- **Comparaison social / privé :** c'est un ordre de grandeur. Le loyer social est hors charges, le loyer d'annonce privé est charges comprises. L'écart réel est donc un peu plus faible que celui affiché.

## Mise à jour (Google Colab)

```python
import requests, pandas as pd, io
H = {'User-Agent': 'Observatoire QPV Action Logement'}
# ORT : liste à jour (format CSV, tableur Grist du ministère)
ort = pd.read_csv(io.StringIO(requests.get('https://grist.numerique.gouv.fr/o/dgaln/api/docs/j4i9oKD3jzFtgEUuM9sXnL/download/csv?tableId=BDD', headers=H).text), dtype=str)
ort.to_csv('ORT_communes_liste_nationale.csv', index=False)
# Monuments historiques : fichier national (environ 46 700 monuments), puis filtre sur les départements de la DR
ds = requests.get('https://www.data.gouv.fr/api/1/datasets/5af120e5b595087cfabcde81/', headers=H).json()
url = [r['url'] for r in ds['resources'] if r['format'] == 'geojson'][0]
g = requests.get(url, headers=H, timeout=600).json()
deps = ['02', '59', '60', '62', '80']
mh = [f for f in g['features'] if f['properties'].get('departement_format_numerique') in deps]
print(len(mh), 'monuments')
# Carte des loyers : chercher le jeu de l'année la plus récente sur data.gouv.fr (« Carte des loyers - Indicateurs de loyers d'annonce par commune »)
ds = requests.get('https://www.data.gouv.fr/api/1/datasets/693aa2feed1bf4da603faa49/', headers=H).json()
for r in ds['resources']:
    if r['format'] == 'csv':
        t = pd.read_csv(r['url'], sep=';', dtype=str, encoding='utf-8')
        t[t.REG == '32'].to_csv('carte_loyers_HDF_' + r['url'].split('/')[-1], sep=';', index=False)
```

Pour une autre DR, remplacer la liste des départements et le code région (`32` pour les Hauts-de-France).
